$(document).ready(() => {
    $('#return-btn').on('click', (event) => {
        window.location.href = '/admin';
    })
});