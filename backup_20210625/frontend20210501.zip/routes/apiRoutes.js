// const router = require("express").Router();

// use this file to code your API routes

// All routes start with: /api

// Route: /api/example
// i.e: router.get("/example", (req, res) => {
//     //your code here
// })

// module.exports = router;