module.exports = {
    API_ADMIN: 'admin',
    API_GUEST: 'client',
    API_LAWYER:'lawyer'
}